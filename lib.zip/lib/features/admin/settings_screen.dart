import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../providers/auth_provider.dart';
import 'admin_scaffold.dart';

class AdminSettingsScreen extends StatelessWidget {
  const AdminSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminScaffold(
      title: 'Settings',
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          _tile(context, Icons.description_outlined, 'Terms & Conditions'),
          _tile(context, Icons.privacy_tip_outlined, 'Privacy Policy'),
          _tile(context, Icons.contact_mail_outlined, 'Contact Information'),
          _tile(context, Icons.cancel_outlined, 'Cancellation Policy'),
          _tile(context, Icons.map_outlined, 'Locations Served'),
          const SizedBox(height: AppSpacing.lg),
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadii.field)),
            child: ListTile(
              leading: const Icon(Icons.logout, color: AppColors.error),
              title: const Text('Log Out of Admin', style: TextStyle(color: AppColors.error)),
              onTap: () {
                context.read<AuthProvider>().logout();
                context.go('/login');
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadii.field)),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(label),
        trailing: const Icon(Icons.chevron_right, color: AppColors.mutedGray),
        onTap: () {},
      ),
    );
  }
}
