import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))
      ..forward();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) context.go('/onboarding');
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFEFF6E9), Color(0xFFDCEBD1), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 24),
              FadeTransition(
                opacity: _controller,
                child: Column(
                  children: [
                    Text('From Land to Life',
                        style: GoogleFonts.dancingScript(
                            fontSize: 22, color: AppColors.primary, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text('Everything You Need, Just a Rental Away',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              const Spacer(),
              ScaleTransition(
                scale: Tween<double>(begin: 0.85, end: 1).animate(
                    CurvedAnimation(parent: _controller, curve: Curves.easeOutBack)),
                child: Column(
                  children: [
                    Container(
                      height: 96,
                      width: 96,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [AppColors.secondary, AppColors.primary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: AppShadows.card,
                      ),
                      alignment: Alignment.center,
                      child: const Text('🌱', style: TextStyle(fontSize: 44)),
                    ),
                    const SizedBox(height: 16),
                    RichText(
                      text: TextSpan(
                        style: GoogleFonts.inter(
                            fontSize: 30, fontWeight: FontWeight.bold, color: AppColors.textDark),
                        children: const [
                          TextSpan(text: 'Krishi', style: TextStyle(color: AppColors.primary)),
                          TextSpan(text: 'Rent'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('Rent · Grow · Together',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: AppColors.secondary, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 60),
                child: Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: _controller.value,
                        minHeight: 6,
                        backgroundColor: AppColors.cardBorder,
                        valueColor: const AlwaysStoppedAnimation(AppColors.secondary),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text('Growing Opportunities...', style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
