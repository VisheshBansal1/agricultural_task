import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../providers/resource_provider.dart';
import '../../widgets/admin_stat_card.dart';
import '../../widgets/app_button.dart';
import '../../widgets/booking_card.dart';

class OwnerDashboardScreen extends StatelessWidget {
  const OwnerDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final ownerId = auth.currentUser?.id ?? 'o1';
    final resources = context.watch<ResourceProvider>();
    final bookings = context.watch<BookingProvider>();

    final myResources = resources.forOwner(ownerId);
    final myBookings = bookings.forOwner(ownerId);
    final pendingRequests = myBookings.where((b) => b.status == BookingStatus.pending).toList();
    final earnings = myBookings
        .where((b) => b.status == BookingStatus.completed || b.status == BookingStatus.active || b.status == BookingStatus.confirmed)
        .fold<double>(0, (sum, b) => sum + b.rentalAmount);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Owner Dashboard'),
        actions: [
          IconButton(onPressed: () => context.push('/home'), icon: const Icon(Icons.storefront_outlined)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          children: [
            Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              decoration: BoxDecoration(
                gradient: AppGradients.heroSubtle,
                borderRadius: BorderRadius.circular(AppRadii.card),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Welcome back,', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70)),
                        Text(auth.currentUser?.name ?? 'Owner',
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white)),
                        const SizedBox(height: 6),
                        Text('Turn idle assets into income', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white70)),
                      ],
                    ),
                  ),
                  const Text('🚜', style: TextStyle(fontSize: 40)),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.5,
              children: [
                AdminStatCard(label: 'Total Earnings', value: '₹${earnings.toStringAsFixed(0)}', icon: Icons.currency_rupee, color: AppColors.success),
                AdminStatCard(label: 'My Resources', value: '${myResources.length}', icon: Icons.inventory_2_outlined, color: AppColors.info),
                AdminStatCard(label: 'Pending Requests', value: '${pendingRequests.length}', icon: Icons.hourglass_bottom, color: AppColors.warning),
                AdminStatCard(label: 'Total Bookings', value: '${myBookings.length}', icon: Icons.calendar_month_outlined, color: AppColors.primary),
              ],
            ),
            const SizedBox(height: AppSpacing.xl),
            AppButton(label: 'Add New Resource', icon: Icons.add, onPressed: () => context.push('/owner/add-resource')),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: [
                Expanded(
                  child: AppButton(
                    label: 'My Resources',
                    variant: AppButtonVariant.secondary,
                    onPressed: () => context.push('/owner/resources'),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: AppButton(
                    label: 'Requests',
                    variant: AppButtonVariant.secondary,
                    onPressed: () => context.push('/owner/requests'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xl),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Recent Requests', style: Theme.of(context).textTheme.titleMedium),
                TextButton(onPressed: () => context.push('/owner/requests'), child: const Text('View All')),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            if (myBookings.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.xl),
                child: Text('No booking requests yet.', style: Theme.of(context).textTheme.bodyMedium),
              )
            else
              ...myBookings.take(3).map((b) => BookingCard(booking: b, onTap: () => context.push('/owner/requests/${b.id}'))),
          ],
        ),
      ),
    );
  }
}
